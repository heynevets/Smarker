from django.db import models

class StatusModel(models.Model):
    datetime = models.DateTimeField(auto_now_add=True, blank=True)
    status = models.CharField(max_length=30)

