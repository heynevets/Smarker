from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from app.models import StatusModel
import datetime

# Create your views here.
def index(request):
	if 'status' in request.GET:
		s = StatusModel(status=request.GET['status'])
		s.save()
		return HttpResponse(request.GET['status'])

	data = StatusModel.objects.all().order_by("-id").values_list()

	dt = data[0][1] + datetime.timedelta(hours=-7)
	dt = str(dt)[:-13]
	return render(request, 'app/index.html', {'dt': dt})
